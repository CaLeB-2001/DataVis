
from flask import Flask, render_template, request
import os
from matplotlib import pyplot as plt
import tweepy as tp
import pandas as pd
import re
from textblob import TextBlob
from Twitter_Project.FlaskTutorial.twitter import df
from twitter_auth import *
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['CSV_FOLDER'] = 'static/CSV'


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/chart')
def chart(p, n, neu):
    labels = ['positive', 'negative', 'neutral']
    values = [p, n, neu]

    plt.title('Sentiment Analysis')

    plt.pie(values, labels=labels, autopct='%1.1f%%')

    plt.show()

    return render_template('chart.html')


@app.route('/dd')
def dd():
    return render_template('DrillDownDemo.html')


@app.route('/process', methods=['POST'])
def process():
    if request.method == 'POST':
        print('in post')
        data = request.files['myFile']
        data.save(os.path.join(app.config['UPLOAD_FOLDER'], data.filename))

    return render_template('process.html', filename=os.path.join(app.config['UPLOAD_FOLDER'], data.filename))


#def get_polarity(tweets):
 #   return (tweets['sentiment'] > .25).sum(), (tweets['sentiment'] < -.25).sum(), (
  #   tweets['sentiment'].between(-.25, .25)).sum()


#def clean_tweet(input):
 #   return re.sub('[^A-Za-z0-9]+', "", input)


def get_clean_tweets(query):
    auth = tp.OAuthHandler(API_KEY, API_SECRET)
    auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)

    api = tp.API(auth)

    vdr = SentimentIntensityAnalyzer

    tweets = tp.Cursor(api.search_tweets, q=search, lang="eng").items(50)

    list = []

    id = 0

    for tweet in tweets:
        sentiment = TextBlob(tweet.text).sentiment.polarity

        tweets[id] = {

            'id': id,
            'username': tweet.user.name,
            'location': tweet.user.location,
            'Sentiment': vdr.polarity_scores(tweet.text)['compound']
        }
        id += 1

        df = pd.DataFrame.from_dict(tweets, orient='index')

        df.to_csv("output.csv", sep=",")

        df.set_index('id', inplace=True)

        return tweets, df


if __name__ == '__main__':
    search = input("Enter topic:")

    get_clean_tweets(search)

    #positive, negative, neutral = get_polarity(df)

    #chart(positive, negative, neutral)

    app.run(debug=True)
