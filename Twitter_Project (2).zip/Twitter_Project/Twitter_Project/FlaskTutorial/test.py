import json
import pandas as pd

def create_entries(data, value):
    list_item = {}
    series_list_item = {}

    list_item['name'] = current_value
    list_item['id'] = current_value
    list_item['data'] = data

    series_list_item['name'] = current_value
    series_list_item['y'] = value
    series_list_item['drilldown'] = current_value

    series_data.append(series_list_item)

    data = []
    value = 0
    drilldown['series'].append(list_item)

df = pd.read_csv('static/CSV/Book1.csv', header=None)
series = {}
drilldown = {}

series['name'] = 'Tweets'
series['colorByPoint'] = 'true'

drilldown['series'] = []
current_value = None
data = []
series_data = []
value = 0

for row in df.iterrows():

    ent = row[1]

    id = ent[0]
    cat = ent[1]
    val = ent[2]

    if current_value == None:
        current_value = id

    if id != current_value:
        create_entries(data, value)
        current_value = id

    data.append([cat, val])
    value += val

create_entries(data, value)

series['data'] = series_data

series = json.dumps(series)
drilldown = json.dumps(drilldown)

print(drilldown)
print(series)