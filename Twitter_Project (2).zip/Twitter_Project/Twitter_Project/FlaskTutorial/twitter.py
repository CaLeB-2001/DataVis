import tweepy as tp
import pandas as pd
from textblob import TextBlob

from twitter_auth import *

auth = tp.OAuthHandler(API_KEY, API_SECRET)
auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)

api = tp.API(auth)

tweets = api.search_tweets(q='Arsenal')

list = []

id = 0


for tweet in tweets:
    sentiment = TextBlob(tweet.text).sentiment.polarity
    if tweet.lang != "en":
        continue

    tweets[id] = {

        'id': id,
        'username': tweet.user.name,
        'location': tweet.user.location,
    }
# if statements for tweet polarity

    if sentiment > 0.15:
        sentiment = 'positive'
    elif sentiment < -.15:
        sentiment = 'neg'
    else:
        sentiment = 'neu'

    list.append((tweet.text, sentiment))

df = pd.DataFrame(list)

df.to_csv("output.csv", sep=",")
